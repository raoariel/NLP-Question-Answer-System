def give_questions(file, number):
        from parseNLPold import Parse
        from extractNLPold import Extract
        file = Parse(file)
        ret = ""
        n = 0
        while(n < number):
                print 0
                parsed = file.getContent()
                print 1
                phrases = Extract(parsed)
                print 2
                if(("VP" in phrases.getText().keys()) and ("NP" in phrases.getText().keys())):
                        q = phrases.get_questions()
                        if((q is not None) and (len(q) > 0) and (q[len(q)-1] == '?')):
                                n += 1
                        ret += q + "\n"
                        print ("\n\n\n" + q + "\n")
                else:
                        print phrases.getText()
                        print "\n"
        print "done"
        return ret

give_questions("languages_a9.htm",10)