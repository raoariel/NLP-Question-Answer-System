import os, sys, re, string, ast, json, yaml
from  nltk import *
from corenlp import *
from random import randint
from bs4 import BeautifulSoup
from collections import Counter

debug = False
# non deterministically find important content

class Parse(object):
    # textRange 15
    def __init__(self,fileName,dataDir='../sampleData/languages/',textRange=5,ignoreUnicode=True):
        self.fileName = fileName
        self.textRange = textRange+1 # lines of text to search over, +1 for range offset
        self.dataDir = dataDir
        #print("Reading file..."),
        self.readFile()
        #print("OK!")
        #print("Tokenizing file..."),
        self.tokenize()
        #print("OK!")
        #print("Starting StanfordCoreNLP..."),
        self.corenlp = StanfordCoreNLP()
        #print("OK!")
        return

    def readFile(self):
        html = BeautifulSoup(open(self.dataDir+self.fileName))
        self.raw = html.get_text()
        return 

    def tokenize(self):
        try: 
          misc = self.raw.index("See also")
          self.raw = self.raw[:misc]
        except:
          pass
        self.text = tokenize.sent_tokenize(self.raw)
        self.textLen = len(self.text)
        return

    def parse(self):
        self.parsedText = []
        for line in self.text:
            if isinstance(line, unicode):
                strLine = line.encode('ascii', 'xmlcharrefreplace')
                try:
                    self.parsedText.append(yaml.load(self.corenlp.parse(strLine)))
                except: raise Exception ("Failed coreNLP parse. \n Text: ", line)
            else: raise Exception ("Invalid encoding for text file.")
        return        

    def getNECounts(self,line): 
        try:
            sentence = line[0]['words']
            for token in sentence:
                word = token[0]
                info = token[1]
                if info['NamedEntityTag'] != 'O':
                    self.NEcounts[word] += 1
                elif info['PartOfSpeech'] == "NN":
                    self.NEcounts[word] += 1
        except:
            raise Exception ("Failed coreNLP parse. \n Text: ", line)
        return

    def getTopicSentence(self,topicNE):
        self.topicInd = -1 #get sentence with topic in it
        ind = 0
        tries = 0
        while ((self.topicInd < 0) and (tries < 5)):
            try:
                tmp = self.parsedText[ind]['sentences'][0]['text']
                if topicNE in tmp:
                   self.topicInd = ind
                else: ind += 1
            except:
                tries += 1
                pass
        if tries >= 5: self.getContent()
        return

    def treeToList(self,parseTree):
        """Convert parse tree from string to nested array"""
        validChar = string.ascii_letters + string.digits + "() "
        filterChars = (lambda x: ((x in string.punctuation) or
                                  (x not in string.punctuation) or 
                                  (x in "() ")))
        parseTree = ''.join(filter(filterChars, parseTree))
        parseTree = parseTree.replace('(', '[')
        parseTree = parseTree.replace(')', ']')
        parseTree = parseTree.replace('] [', '], [')
        parseTree = parseTree.replace('[]', '')
        parseTree = parseTree.replace('[ ]', '')
        parseTree = re.sub(r'(\w+)', r'"\1",', parseTree)
        # punctuation edge cases. may be more not fully tested
        parseTreef = parseTree.replace('.', '')
        parseTreef = parseTree.replace('!', '')
        parseTreef = parseTreef.replace(', ,', '')
        parseTreef = parseTreef.replace(':', '')
        parseTreef = parseTreef.replace(';', '')
        parseTreef = parseTreef.replace('``', '')
        parseTreef = parseTreef.replace('\'', '')
        parseTreef = parseTreef.replace('-', '')
        parseTreef = parseTreef.replace('+', '') # will fail for c++
        parseTreef = parseTreef.replace(',]', ']')
        try:
            return ast.literal_eval(parseTreef)
        except:
            print parseTreef
            return []

    def treeToList2(self,parseTree):
        """Convert parse tree from string to nested array"""
        validChar = string.ascii_letters + string.digits + "() "
        filterChars = (lambda x: ((x in string.punctuation) or
                                  (x not in string.punctuation) or 
                                  (x in "() ")))
        parseTree = ''.join(filter(filterChars, parseTree))
        parseTree = parseTree.replace('(', '["')
        parseTree = parseTree.replace(')', '"]')
        parseTree = parseTree.replace(', ', '", "')
        parseTree = parseTree.replace('] [', '], [')
        parseTree = parseTree.replace('[]', '')
        while ((']"]' in parseTree) or ('["[' in parseTree)):
            parseTree = parseTree.replace(']"]', ']]')
            parseTree = parseTree.replace('["[', '[[')
        # punctuation edge cases. may be more not fully tested
        try:
            return ast.literal_eval(parseTreef)
        except:
            print parseTree
            return []

    def decomposePhrase(self):
        while (type(phrase) == list) and (phase[1][0] != 'NP'):
                phrase = phrase[1]
        #print(phrase[1],phrase[3])
        #FINISH LATER IF NEEDED
        return

    def getContent(self):
        # assumption, python PRNG goodish
        #assumption, something worthwhile ever 15 sentences
        (lineFound,attempts) = (False,0)
        startInd = randint(0,self.textLen-self.textRange)
        self.parsedText = []
        self.NEcounts = Counter()
        print ("Parsing lines: "),
        for lineInd in xrange(startInd,startInd+self.textRange):
            print lineInd,
            line = self.text[lineInd]
            if isinstance(line, unicode):
                exclude = set(string.punctuation)
                strLine = line.encode('ascii', 'xmlcharrefreplace')
                try: 
                    strLine = ''.join(ch for ch in strLine if ch not in exclude)    
                    res = json.loads(self.corenlp.parse(strLine))
                    self.parsedText.append(res)
                    self.getNECounts(res['sentences'])
                except: pass
            else: raise Exception ("Invalid encoding for text file.")

        print "Block Complete."
        uniqueNE = len(list(self.NEcounts))
        topNE = uniqueNE 
        mostCommonNE = [k for (k,v) in self.NEcounts.most_common(topNE)]
        
        while ((not lineFound) and (attempts < 5)):
            topicNE = mostCommonNE[randint(0,max(1,topNE-1))]
            #print topicNE
            self.getTopicSentence(topicNE)
            try:
                parseTree = self.parsedText[self.topicInd]['sentences'][0]['parsetree']
                rawSentence = self.parsedText[self.topicInd]['sentences'][0]['text']
            except: 
                raise Exception ("Invalid parse. Could not decode results.")
            self.parseTree = self.treeToList(parseTree)
            if self.parseTree == []: self.getContent()
            try:
                selectedPhrase = self.parseTree[1] # ROOT extracted
            except:
                selectedPhrase = self.parseTree
            #print selectedPhrase 
            #print rawSentence
            if len(rawSentence.split()) > 6:
                lineFound = True
            attempts += 1
        if (attempts > 5): 
            #print "Timeout finding line with good content. Trying new block..."
            self.getContent()
        
        # #(phraseNP,phraseVP) = decomposePhrase(self)
        # #return raw line with parse, NP pharse, VP phrase
        # #return (phrase,rawSentence,phraseNP,phraseVP)
        print "complete"
        return (selectedPhrase,rawSentence)













